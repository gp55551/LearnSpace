package SelenumRelated;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
//extent report 2.41.2 requires all dependances
public class ExtentReportGeneration {

	static ExtentReports extent ; 
	static ExtentTest tests ;
	static String filePath = System.getProperty("user.dir")+"\\extentreportsOLD\\ExtentReport.html"; 
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		extent = new ExtentReports(filePath, true);
		extent.loadConfig(new File(System.getProperty("user.dir")+"\\extentreportsOLD\\config.xml"));

		tests = extent.startTest("Title Verification");
		tests.assignAuthor("Gaurav Patnaik");

		WebDriver driver;
		System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "\\IEDriver\\IEDriverServer.exe");

		DesiredCapabilities dc = DesiredCapabilities.internetExplorer();
		driver = new InternetExplorerDriver(dc);
		System.out.println("Driver initiated");
		tests.log(LogStatus.PASS, "Driver initiated : Passed");

		driver.get("http://www.demo.guru99.com/v4/");
		System.out.println("navigated to URL");
		tests.log(LogStatus.PASS, "Navigated to URL : Passed");
		String title = driver.getTitle();
		System.out.println(title);
		if (title.equals("Guru99 Bank Home Page")) {
			System.out.println("matching");
			tests.log(LogStatus.PASS, "Script Passed");
		} else {
			System.out.println("not matching");
			tests.log(LogStatus.FAIL, "Script Failed");

		}

		System.out.println("closing browser");
		tests.log(LogStatus.PASS, "Closing browser");
		driver.quit();

		
		extent.endTest(tests);
		extent.flush();
		extent.close();
		
	}

}
