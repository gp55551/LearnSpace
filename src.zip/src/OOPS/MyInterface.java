package OOPS;

public interface MyInterface {

	void method1();
}
