package OOPS;

import java.util.ArrayList;
import java.util.Collections;


public class Strings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> array=new ArrayList<String>();
		array.add("gaurav");
		array.add("saran");
		array.add("mike");
		array.add("vignesh");
		array.add("shivendu");
		Collections.sort(array);
		System.out.println(array);
		
		String[] car = {"dfd","sdfsd"};
		for (int a=0 ; a <car.length ; a++)
		{
			System.out.println(car[a]);
		}
		
		
		String[] a = new String[12];
		
		
		
		
		
		
		

	}
	
	

}
