package lexJava;

public class arrayoutOfBound {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = new int[6];
		System.out.println(arr[3]);
		
		//no compilation error
	}

}
